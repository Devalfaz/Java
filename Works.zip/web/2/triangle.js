function checkTriangle(x,y,z) 
{ 
  
    // Check for equilateral triangle 
    if (x == y && y == z ) 
        return ("Equilateral Triangle"); 
  
    // Check for isoceles triangle 
    else if (x == y || y == z || z == x ) 
        return ("Isoceles Triangle"); 
  
    // Otherwise scalene triangle 
    else
        return ("Scalene Triangle"); 
}


function triangle(){
    var number1=document.myform.number1.value;
    var number2=document.myform.number2.value;
    var number3=document.myform.number3.value;

    

       if(checkValidity){
           alert("The triangle is valid and The Triangle is "+ checkTriangle(number1,number2,number3));
       }
       else{
        alert("triangle is not valid");
      
       }

    
}

function checkValidity(x,y,z) 
{ 
    // check condition 
    if (x + y <= z || x + z <= y || y + z <= x) 
        return false; 
    else
        return true; 
}