
function year(){
    var number1=document.myform.number1.value;
    var number2=document.myform.number2.value;

for (var year = number1; year <= number2; year++)
    {
    var d = new Date(year, 0, 1);
    if ( d.getDay() === 0 )
       document.write("1st January is being a Sunday "+year+"<br>");
    }
}