function perfectno(){
    var number=document.myform.number.value;
    // alert(number);
    var temp=0;
   for(var i=1;i<=number/2;i++){
      
       if(number%i === 0){
           temp=temp+i;
       }
    }
    // alert(temp);

       if(temp === Number(number) && temp !== 0){
           alert(Number(number)+" is a"+" Perfect Number");
       }
       else{
        alert(Number(number)+" is a"+" Deficient Number");
      
       
       }

    
}